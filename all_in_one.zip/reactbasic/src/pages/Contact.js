const Contact = () => (
  <div className="container">
    <div className="row">
      <div className="col-md-8 offset-md-2">
        <h1>Contact</h1>
        <hr />
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nesciunt id,
          veniam quo aperiam eius laudantium maiores exercitationem repellat
          dolorum iste numquam consequuntur dolores quibusdam molestiae placeat
          natus aut, ullam sint? Laudantium amet quasi, cupiditate nulla illo
          modi iure ab ullam minus sunt iusto, earum, ex quidem asperiores est
          optio nobis quaerat voluptatibus? Eveniet ducimus eligendi, esse
          dolores totam iusto quos molestiae, consequuntur quo vero, adipisci
          impedit provident repudiandae. Rerum libero modi ipsam ab sint nemo
          necessitatibus distinctio, porro nisi est laudantium consectetur
          inventore iste repudiandae dolorum quisquam maxime doloribus, non
          esse! Modi inventore asperiores cupiditate sint laborum, odit nobis
          voluptatum.
        </p>
      </div>
    </div>
  </div>
);

export default Contact;
