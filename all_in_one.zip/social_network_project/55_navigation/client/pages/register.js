const Register = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <h1>Register page</h1>
        </div>
      </div>
    </div>
  );
};

export default Register;
