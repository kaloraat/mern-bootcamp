const Login = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <h1>Login page</h1>
        </div>
      </div>
    </div>
  );
};

export default Login;
