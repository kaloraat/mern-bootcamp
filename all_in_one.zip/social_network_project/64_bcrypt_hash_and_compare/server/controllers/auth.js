export const register = (req, res) => {
  console.log("REGISTER ENDPOINT => ", req.body);
};
